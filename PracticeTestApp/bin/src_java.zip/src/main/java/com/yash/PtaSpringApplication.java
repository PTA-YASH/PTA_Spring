package com.yash;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


//Main class which starts the application. 
@SpringBootApplication
public class PtaSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(PtaSpringApplication.class, args);
	}
}

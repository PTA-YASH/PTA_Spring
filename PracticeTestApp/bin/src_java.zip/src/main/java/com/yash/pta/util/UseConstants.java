package com.yash.pta.util;

public final class UseConstants {

	public static String EMPTY_TECHNOLOGY_LIST="Technology list is empty";
}

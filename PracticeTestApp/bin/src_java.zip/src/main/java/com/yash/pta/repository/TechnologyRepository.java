package com.yash.pta.repository;

import org.springframework.data.repository.CrudRepository;

import com.yash.pta.model.Technology;


public interface TechnologyRepository extends CrudRepository<Technology,Integer> {

}
